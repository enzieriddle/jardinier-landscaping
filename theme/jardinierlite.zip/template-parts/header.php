<?php
/**
 * Template part for default Header layout.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Jardinierlite
 */
?>

<?php get_template_part( 'template-parts/top-panel' ); ?>

<div <?php jardinierlite_header_class(); ?>>
	<?php do_action( 'jardinierlite-theme/header/before' ); ?>
	<div class="space-between-content">
		<div <?php jardinierlite_site_branding_class(); ?>>
			<?php jardinierlite_header_logo(); ?>
		</div>
		<?php jardinierlite_main_menu(); ?>
	</div>
	<?php do_action( 'jardinierlite-theme/header/after' ); ?>
</div>


