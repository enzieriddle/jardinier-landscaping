<?php
/**
 * The template for displaying the default footer layout.
 *
 * @package Jardinierlite
 */
?>

<?php do_action( 'jardinierlite-theme/widget-area/render', 'footer-area' ); ?>

<div <?php jardinierlite_footer_class(); ?>>
	<div class="space-between-content"><?php
		jardinierlite_footer_copyright();
		jardinierlite_social_list( 'footer' );
	?></div>
</div><!-- .container -->
