<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Jardinierlite
 */

?>

<header class="entry-header">
	<?php the_title( '<h1 class="entry-title h2-style">', '</h1>' ); ?>
	<div class="entry-meta">
		<?php
			jardinierlite_posted_by();
			jardinierlite_posted_in( array(
				'prefix'  => __( 'In', 'jardinierlite' ),
			) );
			jardinierlite_posted_on( array(
				'prefix'  => __( 'Posted', 'jardinierlite' ),
			) );
			jardinierlite_post_comments( array(
				'postfix' => __( 'Comment(s)', 'jardinierlite' ),
			) );
		?>
	</div><!-- .entry-meta -->
</header><!-- .entry-header -->

<?php jardinierlite_post_thumbnail( 'jardinierlite-thumb-l', array( 'link' => false ) ); ?>