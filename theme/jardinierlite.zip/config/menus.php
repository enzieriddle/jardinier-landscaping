<?php
/**
 * Menus configuration.
 *
 * @package Jardinierlite
 */

add_action( 'after_setup_theme', 'jardinierlite_register_menus', 5 );
function jardinierlite_register_menus() {

	register_nav_menus( array(
		'main'   => esc_html__( 'Main', 'jardinierlite' ),
		'footer' => esc_html__( 'Footer', 'jardinierlite' ),
		'social' => esc_html__( 'Social', 'jardinierlite' ),
	) );
}
