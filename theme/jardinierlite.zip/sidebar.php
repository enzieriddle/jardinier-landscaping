<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Jardinierlite
 */

?>

<?php 

do_action( 'jardinierlite-theme/sidebar/before' );

if ( is_active_sidebar( 'sidebar' ) && 'none' !== jardinierlite_theme()->sidebar_position ) : ?>
	<aside id="secondary" <?php jardinierlite_secondary_content_class( array( 'widget-area' ) ); ?>>
		<?php dynamic_sidebar( 'sidebar' ); ?>
	</aside><!-- #secondary -->
<?php endif; 

do_action( 'jardinierlite-theme/sidebar/after' );
